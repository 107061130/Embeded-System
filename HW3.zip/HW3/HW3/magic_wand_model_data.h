#ifndef MAGIC_WAND_MODEL_DATA_H_
#define MAGIC_WAND_MODEL_DATA_H_

extern const unsigned char g_magic_wand_model_data[];
extern const int g_magic_wand_model_data_len;

#endif  // MAGIC_WAND_MODEL_DATA_H_